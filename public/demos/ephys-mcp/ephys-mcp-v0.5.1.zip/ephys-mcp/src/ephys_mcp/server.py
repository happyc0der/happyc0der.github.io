"""MCP server exposing read-only analysis of intracortical recordings.

Tools return compact summaries, never raw arrays, so results fit in an LLM
context window.
"""

from __future__ import annotations

import functools
import logging
import uuid
from typing import Any, Literal

import httpx
import numpy as np
from mcp.server.mcpserver import Image, MCPServer
from mcp.server.mcpserver.exceptions import ToolError

from . import plots
from .processing import geometry
from .processing.decode import DECODERS, r2_score
from .processing.latent import MAX_FACTORS, fit_gpfa, fit_pca
from .processing.latent import summarize as summarize_latent
from .processing.psth import aligned_counts, compute_psth, modulation, summarize, usable_events
from .processing.quality import signal_quality
from .processing.rates import bin_spikes, firing_stats, resample_to
from .processing.sorting import SortedSource, sort_window
from .processing.spikes import detect_spikes as _detect_spikes
from .processing.spikes import match_spikes
from .sources import SOURCES, NeuralSource
from .sources import dandi as _dandi
from .sources import lsl as _lsl
from .sources.base import MAX_GROUPS
from .sources.live import RingBufferSource

DISCLAIMER = (
    "Research and education software. Not a medical device, not for clinical use, "
    "and not affiliated with or endorsed by any implant manufacturer."
)

mcp = MCPServer(
    "ephys-mcp",
    instructions=(
        "Read-only analysis of intracortical (spike-level) brain-computer-interface recordings. "
        "Start with list_sources, then open_session, then inspect with get_session_info. "
        "Tools return summaries rather than raw samples. " + DISCLAIMER
    ),
)

logging.getLogger("httpx").setLevel(logging.WARNING)

WARMUP_S = 1.0  # lead-in so stateful decoders converge before the requested window


def tool(fn=None, **options):
    """Register an MCP tool whose anticipated failures reach the model as readable messages."""
    if fn is None:
        return lambda f: tool(f, **options)

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except httpx.HTTPError as exc:
            raise ToolError(f"DANDI Archive request failed: {exc}") from exc
        except (ValueError, KeyError, NotImplementedError) as exc:
            raise ToolError(str(exc.args[0]) if exc.args else type(exc).__name__) from exc

    mcp.tool(**options)(wrapper)
    return wrapper


_sessions: dict[str, NeuralSource] = {}
_decoders: dict[str, dict[str, Any]] = {}
_latents: dict[str, dict[str, Any]] = {}
_probes: dict[str, np.ndarray] = {}  # user-supplied contact positions, by session


def _session(session_id: str) -> NeuralSource:
    try:
        return _sessions[session_id]
    except KeyError:
        raise ValueError(f"unknown session_id {session_id!r}; call open_session first") from None


def _range(src: NeuralSource, t0: float, t1: float | None) -> tuple[float, float]:
    info = src.info()
    start, end = info.t_start_s, info.t_start_s + info.duration_s
    t1 = end if t1 is None else min(t1, end)
    t0 = max(t0, start)
    if not t0 < t1:
        raise ValueError(f"need {start} <= t0 < t1 <= {end}")
    return t0, t1


def _recorded_mask(src: NeuralSource, t: np.ndarray, bin_s: float) -> np.ndarray:
    """True for bins that lie wholly inside a span where data was recorded."""
    iv = src.valid_intervals()
    lo, hi = t - bin_s / 2, t + bin_s / 2
    k = np.clip(np.searchsorted(iv[:, 0], lo, side="right") - 1, 0, len(iv) - 1)
    return (lo >= iv[k, 0] - 1e-9) & (hi <= iv[k, 1] + 1e-9)


def _pick_target(src: NeuralSource, target: str | None) -> str:
    signals = src.info().behavior_signals
    if target:
        if target not in signals:
            raise ValueError(f"unknown target {target!r}; available: {sorted(signals)}")
        return target
    for name in signals:
        if "vel" in name.lower():
            return name
    raise ValueError(f"no velocity-like signal found; pass target explicitly from: {sorted(signals)}")


@tool
def list_sources() -> dict:
    """List the data source types this server can open, with their parameters and status."""
    return {
        "sources": [
            {"name": k, "status": v["status"], "description": v["description"], "default_params": v["params"]}
            for k, v in SOURCES.items()
        ],
        "disclaimer": DISCLAIMER,
    }


@tool
def open_session(source: str = "synthetic", params: dict[str, Any] | None = None) -> dict:
    """Open a recording session and return its session_id and metadata.

    `params` overrides the source's default_params (see list_sources).
    """
    if source not in SOURCES:
        raise ValueError(f"unknown source {source!r}; options: {sorted(SOURCES)}")
    defaults = SOURCES[source]["params"]
    unknown = sorted(set(params or {}) - set(defaults))
    if unknown:
        raise ValueError(f"unknown params {unknown} for source {source!r}; valid: {sorted(defaults)}")
    try:
        src = SOURCES[source]["cls"](**{**defaults, **(params or {})})
    except TypeError as exc:
        raise ValueError(f"bad params for source {source!r}: {exc}") from exc
    sid = uuid.uuid4().hex[:8]
    _sessions[sid] = src
    return {"session_id": sid, **src.info().to_dict()}


@tool
def close_session(session_id: str) -> dict:
    """Close a session and drop any decoder fitted on it."""
    _session(session_id).close()
    del _sessions[session_id]
    _decoders.pop(session_id, None)
    _latents.pop(session_id, None)
    _probes.pop(session_id, None)
    return {"closed": session_id}


@tool
def get_session_info(session_id: str) -> dict:
    """Metadata for a session: duration, channels, sampling rates, behaviour signals, licence, citation."""
    return _session(session_id).info().to_dict()


@tool
def get_signal_quality(session_id: str, t0: float = 0.0, duration_s: float = 2.0) -> dict:
    """Noise level, SNR and dead/noisy channels from a broadband snippet (max 10 s)."""
    src = _session(session_id)
    info = src.info()
    if info.raw_fs_hz is None:
        raise ValueError("this session has no broadband signal")
    raw = src.read_raw(t0, t0 + min(duration_s, 10.0))
    return {**signal_quality(raw, info.raw_fs_hz), "amplitude_unit": info.amplitude_unit}


@tool
def detect_spikes(session_id: str, t0: float = 0.0, duration_s: float = 2.0, threshold_sigma: float = -4.5) -> dict:
    """Threshold-crossing spike detection on a broadband snippet (max 10 s).

    Where the session has ground-truth spikes, precision and recall are reported.
    """
    src = _session(session_id)
    info = src.info()
    if info.raw_fs_hz is None:
        raise ValueError("this session has no broadband signal")
    t1 = t0 + min(duration_s, 10.0)
    raw = src.read_raw(t0, t1)
    spikes, sigma = _detect_spikes(raw, info.raw_fs_hz, threshold_sigma)
    counts = np.array([s.size for s in spikes])
    out = {
        "window_s": [t0, t1],
        "threshold_sigma": threshold_sigma,
        "total_spikes": int(counts.sum()),
        "median_rate_hz": round(float(np.median(counts) / (t1 - t0)), 2),
        "median_noise": round(float(np.median(sigma)), 2),
        "amplitude_unit": info.amplitude_unit,
    }
    if info.has_sorted_spikes and not isinstance(src, SortedSource) and info.n_channels == raw.shape[1]:
        truth = src.spike_times(t0, t1)  # a source whose units are known, one per channel
        scores = [match_spikes(d + t0, tr) for d, tr in zip(spikes, truth)]
        out["vs_ground_truth"] = {
            "median_precision": round(float(np.median([s["precision"] for s in scores])), 3),
            "median_recall": round(float(np.median([s["recall"] for s in scores])), 3),
        }
    return out


def _positions(session_id: str, src: NeuralSource) -> np.ndarray | None:
    """Contact positions for the raw channels: what the user set for this session, else the file's."""
    if session_id in _probes:
        return _probes[session_id]
    inner = src.inner if isinstance(src, SortedSource) else src
    return inner.channel_positions()


@tool
def set_probe_geometry(
    session_id: str,
    layout: Literal["linear", "grid", "utah", "tetrode_linear", "explicit"] = "utah",
    pitch_um: float = 400.0,
    n_columns: int = 0,
    positions_um: list[list[float]] | None = None,
) -> dict:
    """Tell the server where the recording's contacts are, for sessions whose file does not say.

    Named layouts: 'utah' (square grid, e.g. 96 contacts at 400 um), 'grid' with n_columns,
    'linear' (one column at pitch_um, e.g. a laminar probe), 'tetrode_linear' (groups of four).
    'explicit' takes positions_um as [[x, y], ...] in channel order. Geometry is used by
    sort_spikes and plot_probe. Contacts under 100 um apart are sorted jointly.
    """
    src = _session(session_id)
    inner = src.inner if isinstance(src, SortedSource) else src
    n = inner.info().n_channels
    if layout == "explicit":
        if not positions_um:
            raise ValueError("positions_um is required for layout='explicit'")
        pos = np.asarray(positions_um, dtype=float)
        if pos.shape != (n, 2) or not np.isfinite(pos).all():
            raise ValueError(f"positions_um must be {n} finite [x, y] pairs, one per channel")
    else:
        pos = geometry.make_layout(layout, n, pitch_um, n_columns)
    _probes[session_id] = pos
    return {"session_id": session_id, "layout": layout, **geometry.summarize(pos)}


@tool
def get_probe(session_id: str, max_rows: int = 256) -> dict:
    """Contact geometry and brain-area labels per channel, where known. Use the `channel`
    indices with the `units` argument of get_psth / fit_latent_factors to analyse one area."""
    src = _session(session_id)
    inner = src.inner if isinstance(src, SortedSource) else src
    pos, areas = _positions(session_id, src), inner.channel_areas()
    n = inner.info().n_channels
    out: dict[str, Any] = {
        "n_channels": n,
        "geometry_source": "user" if session_id in _probes else ("file" if pos is not None else None),
        "areas": {str(k): int(v) for k, v in zip(*np.unique(areas, return_counts=True))} if areas else {},
    }
    if pos is not None:
        out["geometry"] = geometry.summarize(pos)
    rows = []
    for c in range(min(n, max(1, min(max_rows, 1024)))):
        row: dict[str, Any] = {"channel": c}
        if areas:
            row["area"] = areas[c]
        if pos is not None:
            row["x_um"], row["y_um"] = round(float(pos[c, 0]), 1), round(float(pos[c, 1]), 1)
        rows.append(row)
    out["channels"] = rows
    if n > len(rows):
        out["truncated_to"] = len(rows)
    if pos is None and not areas:
        out["hint"] = "no geometry or area labels in this session; set_probe_geometry can supply a layout"
    return out


@tool(structured_output=False)
def plot_probe(session_id: str, t0: float = 0.0, duration_s: float = 30.0) -> list:
    """Figure: the array map, each contact coloured by its firing rate over a window, with area
    labels and sorted units marked when a sort has been run. Needs geometry from the file or
    set_probe_geometry."""
    src = _session(session_id)
    pos = _positions(session_id, src)
    if pos is None:
        raise ValueError("no probe geometry; call set_probe_geometry first")
    inner = src.inner if isinstance(src, SortedSource) else src
    t0, t1 = _range(inner, t0, t0 + min(max(duration_s, 1.0), 300.0))
    rates = np.array([s.size for s in inner.spike_times(t0, t1)]) / (t1 - t0)
    units = [(u["channel"], u["rate_hz"]) for u in src.units] if isinstance(src, SortedSource) else None
    areas = inner.channel_areas()
    path = plots.plot_probe(f"{session_id}-probe", f"Array map · rate over {t0:g}–{t1:g} s", pos, rates, areas, units)
    return _figure(path, window_s=[t0, t1], **geometry.summarize(pos))


@tool
def sort_spikes(
    session_id: str,
    t0: float = 0.0,
    duration_s: float = 60.0,
    sorter: Literal["spykingcircus2", "tridesclous2"] = "spykingcircus2",
    channels: list[int] | None = None,
) -> dict:
    """Spike-sort a broadband window (needs the sort extra). Afterwards the session's spike times
    are the sorted units, restricted to that window, so rates, PSTHs, rasters and decoders use them.

    Uses the session's probe geometry (from the file or set_probe_geometry) so nearby contacts
    are sorted jointly; without geometry each channel is treated as an independent electrode.
    Sorting takes seconds to a few minutes depending on duration and channel count.
    """
    src = _session(session_id)
    if isinstance(src, SortedSource):
        src = src.inner
    t0, t1 = _range(src, t0, t0 + max(1.0, duration_s))
    n_ch = src.info().n_channels
    if channels is not None and (not channels or any(not 0 <= c < n_ch for c in channels)):
        raise ValueError(f"channels must be a non-empty list of indices in 0..{n_ch - 1}")
    positions = _positions(session_id, src)
    trains, units = sort_window(src, t0, t1, sorter, channels, positions)
    _sessions[session_id] = SortedSource(src, trains, units, t0, t1, sorter)
    _decoders.pop(session_id, None)  # fitted on the old units
    _latents.pop(session_id, None)
    good = [u for u in units if u["isi_violation_fraction"] < 0.02]
    return {
        "sorter": sorter,
        "window_s": [t0, t1],
        "geometry": "used" if positions is not None else "none; channels treated as independent electrodes",
        "n_units": len(units),
        "n_units_clean_isi": len(good),
        "amplitude_unit": src.info().amplitude_unit,
        "units": units[:50],
        "note": "session spike times now come from these units; call sort_spikes again to re-sort a different window",
    }


@tool
def get_firing_rates(session_id: str, t0: float = 0.0, t1: float | None = None) -> dict:
    """Population firing-rate summary over a time range (defaults to the whole session)."""
    src = _session(session_id)
    t0, t1 = _range(src, t0, t1)
    iv = np.clip(src.valid_intervals(), t0, t1)
    recorded = float((iv[:, 1] - iv[:, 0]).sum())
    if recorded <= 0:
        raise ValueError("no recorded data in that window")
    stats = firing_stats(src.spike_times(t0, t1), 0.0, recorded)
    return {"window_s": [t0, t1], "recorded_s": round(recorded, 2), **stats}


def _xy(src: NeuralSource, target: str, t0: float, t1: float, bin_s: float, mask: str | None = None):
    """Binned counts and resampled behaviour, keeping only recorded bins (and masked-in bins)."""
    t, counts = bin_spikes(src.spike_times(t0, t1), t0, t1, bin_s)
    bt, bv = src.behavior(target, t0, t1)
    if bt.size < 2:
        raise ValueError("no behaviour samples in that window")
    y = resample_to(bt, bv, t)
    keep = _recorded_mask(src, t, bin_s) & np.isfinite(y).all(axis=1)
    if mask:
        mt, mv = src.behavior(mask, t0, t1)
        if mv.shape[1] != 1:
            raise ValueError(f"mask {mask!r} must be a one-dimensional boolean signal")
        keep &= resample_to(mt, mv.astype(float), t)[:, 0] > 0.5
    if keep.sum() < 10:
        raise ValueError("too little recorded data in that window")
    return t[keep], counts[keep], y[keep]


def _check_mask(src: NeuralSource, mask: str | None) -> str | None:
    if mask and mask not in src.info().behavior_signals:
        raise ValueError(f"unknown mask signal {mask!r}; available: {sorted(src.info().behavior_signals)}")
    return mask or None


@tool
def fit_decoder(
    session_id: str,
    kind: Literal["ridge", "kalman"] = "kalman",
    target: str | None = None,
    train_fraction: float = 0.8,
    bin_s: float = 0.05,
    mask: str | None = None,
) -> dict:
    """Fit a decoder from spike counts to a behaviour signal and score it on held-out data.

    The first `train_fraction` of the session trains; the remainder tests. With no
    `target`, the first velocity-like behaviour signal is used. Unrecorded gaps are skipped.
    `mask` names a boolean behaviour signal (such as FALCON's eval_mask); only bins where it
    is true are used for fitting and scoring.
    """
    src = _session(session_id)
    if not 0.1 <= train_fraction <= 0.95:
        raise ValueError("train_fraction must be in 0.1..0.95")
    if not 0.005 <= bin_s <= 1.0:
        raise ValueError("bin_s must be in 0.005..1.0")
    target = _pick_target(src, target)
    mask = _check_mask(src, mask)
    info = src.info()
    start, dur = info.t_start_s, info.t_start_s + info.duration_s
    split = start + info.duration_s * train_fraction
    _, Xtr, ytr = _xy(src, target, start, split, bin_s, mask)
    _, Xte, yte = _xy(src, target, split, dur, bin_s, mask)
    model = DECODERS[kind](bin_s=bin_s).fit(Xtr, ytr)
    r2 = r2_score(yte, model.predict(Xte))
    _decoders[session_id] = {
        "model": model,
        "target": target,
        "bin_s": bin_s,
        "kind": kind,
        "mask": mask,
        "test_start_s": split,
    }
    return {
        "kind": kind,
        "params": model.params,
        "target": target,
        "mask": mask,
        "bin_s": bin_s,
        "target_unit": info.behavior_units.get(target, ""),
        "n_train_bins": len(Xtr),
        "n_test_bins": len(Xte),
        "train_window_s": [start, round(split, 2)],
        "test_window_s": [round(split, 2), dur],
        "test_r2_per_dim": [round(float(v), 3) for v in r2],
        "test_r2_mean": round(float(r2.mean()), 3),
    }


@tool
def evaluate_cross_session(
    train_session_id: str,
    test_session_ids: list[str],
    kind: Literal["ridge", "kalman"] = "ridge",
    target: str | None = None,
    bin_s: float = 0.02,
    mask: str | None = "eval_mask",
) -> dict:
    """Fit a decoder on one session and score it, unchanged, on other sessions: the question
    benchmarks such as FALCON ask (does a decoder survive to a later day?).

    All sessions must be open and share the same units/channels. `mask` names a boolean
    behaviour signal restricting which bins are scored (FALCON files carry `eval_mask`; pass
    null when the sessions have none). Also reports same-session held-out R² for comparison.
    """
    train = _session(train_session_id)
    tests = [_session(sid) for sid in test_session_ids]
    if not tests:
        raise ValueError("give at least one test session")
    if not 0.005 <= bin_s <= 1.0:
        raise ValueError("bin_s must be in 0.005..1.0")
    target = _pick_target(train, target)
    signals = train.info().behavior_signals
    if mask == "eval_mask" and mask not in signals:
        mask = None  # the default only applies where the file provides it
    mask = _check_mask(train, mask)
    n_units = train.info().n_channels
    for sid, src in zip(test_session_ids, tests):
        if src.info().n_channels != n_units:
            raise ValueError(f"session {sid} has {src.info().n_channels} units, training session has {n_units}")
        if target not in src.info().behavior_signals:
            raise ValueError(f"session {sid} has no behaviour signal {target!r}")
        _check_mask(src, mask)

    def whole(src):
        i = src.info()
        return _xy(src, target, i.t_start_s, i.t_start_s + i.duration_s, bin_s, mask)

    _, X, y = whole(train)
    cut = int(0.8 * len(y))
    same_day = r2_score(y[cut:], DECODERS[kind](bin_s=bin_s).fit(X[:cut], y[:cut]).predict(X[cut:]))
    model = DECODERS[kind](bin_s=bin_s).fit(X, y)
    results = []
    for sid, src in zip(test_session_ids, tests):
        _, Xt, yt = whole(src)
        r2 = r2_score(yt, model.predict(Xt))
        results.append(
            {
                "session_id": sid,
                "uri": src.info().uri,
                "n_bins_scored": len(yt),
                "r2_per_dim": [round(float(v), 3) for v in r2],
                "r2_mean": round(float(r2.mean()), 3),
            }
        )
    return {
        "kind": kind,
        "params": model.params,
        "target": target,
        "mask": mask,
        "bin_s": bin_s,
        "n_units": n_units,
        "train": {"session_id": train_session_id, "uri": train.info().uri, "n_bins": len(y)},
        "train_tail_r2_mean": round(float(same_day.mean()), 3),
        "transfer": results,
        "note": "train_tail_r2_mean is a fit on the first 80% of the training session scored on its last 20%; "
        "a same-day minival session is the better same-day comparison. Ridge is the sensible baseline here; "
        "the Kalman filter assumes shared linear dynamics and fails on scripted open-loop calibration data. "
        "FALCON's official held-out test labels are private, so this is not a leaderboard score.",
    }


@tool
def decode_window(session_id: str, t0: float, duration_s: float = 2.0, max_points: int = 20) -> dict:
    """Decode a window with the fitted decoder; returns a downsampled decoded-vs-true preview."""
    src = _session(session_id)
    if session_id not in _decoders:
        raise ValueError("no decoder fitted; call fit_decoder first")
    d = _decoders[session_id]
    t0, t1 = _range(src, t0, t0 + duration_s)
    lead = min(WARMUP_S, t0 - src.info().t_start_s)
    t, X, y = _xy(src, d["target"], t0 - lead, t1, d["bin_s"], d["mask"])
    keep = t >= t0
    t, y, yhat = t[keep], y[keep], d["model"].predict(X)[keep]
    step = max(1, len(t) // max(1, min(max_points, 100)))
    return {
        "kind": d["kind"],
        "target": d["target"],
        "mask": d["mask"],
        "window_r2_mean": round(float(r2_score(y, yhat).mean()), 3),
        "preview": [
            {"t": round(float(t[i]), 3), "decoded": np.round(yhat[i], 2).tolist(), "true": np.round(y[i], 2).tolist()}
            for i in range(0, len(t), step)
        ],
    }


PREFERRED_EVENTS = ("move_onset_time", "go_cue_time", "target_on_time")


def _aligned(
    src: NeuralSource,
    event: str | None,
    group_by: str | None,
    t_before: float,
    t_after: float,
    units: list[int] | None = None,
):
    """Usable event times per group label, the spikes covering them, and how many events were dropped."""
    if not (0 <= t_before <= 5 and 0 < t_after <= 5):
        raise ValueError("t_before must be in 0..5 s and t_after in (0, 5] s")
    trials = src.trials()
    info = src.info()
    if not info.event_columns:
        raise ValueError("this session has no trial events to align to")
    event = event or next((e for e in PREFERRED_EVENTS if e in trials), info.event_columns[0])
    if event not in info.event_columns:
        raise ValueError(f"unknown event {event!r}; available: {info.event_columns}")
    if group_by and group_by not in info.group_columns:
        raise ValueError(f"cannot group by {group_by!r}; columns with 2..{MAX_GROUPS} values: {info.group_columns}")
    times = np.asarray(trials[event], dtype=float)
    ok = usable_events(times, (-t_before, t_after), src.valid_intervals())
    labels = trials[group_by][ok] if group_by else np.full(int(ok.sum()), "all trials")
    times = times[ok]
    if times.size < 2:
        raise ValueError("fewer than 2 events have a fully recorded window; shorten t_before/t_after")
    groups = {str(g): times[labels == g] for g in np.unique(labels)}
    spikes = src.spike_times(times.min() - t_before, times.max() + t_after + 1e-9)
    if units:
        if min(units) < 0 or max(units) >= len(spikes):
            raise ValueError(f"units must be in 0..{len(spikes) - 1}")
        spikes = [spikes[u] for u in units]
    return event, groups, spikes, int((~ok).sum())


@tool
def get_psth(
    session_id: str,
    event: str | None = None,
    group_by: str | None = None,
    t_before: float = 0.3,
    t_after: float = 0.6,
    bin_s: float = 0.02,
    units: list[int] | None = None,
) -> dict:
    """Peri-stimulus time histogram: firing aligned to a trial event and averaged over trials.

    `event` is one of the session's event_columns (default: movement onset if present).
    `group_by` splits trials by one of its group_columns, e.g. reach direction.
    `units` restricts the analysis to some units; tuning that cancels in the population
    average (such as direction preference) only shows up per unit. Unit numbers in the
    result index into `units` when it is given.
    Returns the population time course, its peak, and the units that change most.
    """
    src = _session(session_id)
    if not 0.005 <= bin_s <= 0.5:
        raise ValueError("bin_s must be in 0.005..0.5")
    event, groups, spikes, dropped = _aligned(src, event, group_by, t_before, t_after, units)
    window = (-t_before, t_after)
    overall = compute_psth(spikes, np.concatenate(list(groups.values())), window, bin_s)
    out = {"event": event, "window_s": list(window), "bin_s": bin_s, "events_dropped_unrecorded": dropped}
    out.update(summarize(overall))
    if group_by:
        out["group_by"] = group_by
        out["groups"] = {}
        for label, times in groups.items():
            s = summarize(compute_psth(spikes, times, window, bin_s), max_points=0, top=0)
            out["groups"][label] = {k: s[k] for k in ("n_events", "baseline_hz", "peak_hz", "peak_time_s")}
    return out


def _behaviour_r2_from_latents(src: NeuralSource, groups: dict, t: np.ndarray, traj: np.ndarray) -> dict | None:
    """How well the top-k factors linearly explain a velocity-like signal, if the session has one."""
    signals = src.info().behavior_signals
    name = next((n for n in signals if "vel" in n.lower()), None)
    if name is None:
        return None
    events = np.concatenate(list(groups.values()))
    bt, bv = src.behavior(name, events.min() + t[0] - 1, events.max() + t[-1] + 1)
    if bt.size < 2:
        return None
    y = np.stack([resample_to(bt, bv, e + t) for e in events]).reshape(-1, bv.shape[1])
    ok = np.isfinite(y).all(axis=1)
    out = {"signal": name}
    for k in sorted({k for k in (1, 2, 3, traj.shape[2]) if k <= traj.shape[2]}):
        X = np.c_[traj[:, :, :k].reshape(-1, k), np.ones(len(y))][ok]
        W = np.linalg.lstsq(X, y[ok], rcond=None)[0]
        out[f"r2_top{k}"] = round(float(r2_score(y[ok], X @ W).mean()), 3)
    return out


@tool
def fit_latent_factors(
    session_id: str,
    method: Literal["gpfa", "pca"] = "gpfa",
    n_factors: int = 6,
    event: str | None = None,
    group_by: str | None = None,
    t_before: float = 0.3,
    t_after: float = 0.6,
    bin_s: float = 0.02,
    units: list[int] | None = None,
) -> dict:
    """Fit low-dimensional latent factors to trial-aligned population activity.

    GPFA (Yu et al. 2009) gives denoised single-trial trajectories and a timescale per factor;
    PCA is the fast, noisier baseline. Look for an elbow in variance_explained_per_factor to
    judge dimensionality. If the session has a velocity-like signal, reports how well the top
    factors explain it. Then plot_latent_factors draws the trajectories.
    """
    src = _session(session_id)
    if not 1 <= n_factors <= MAX_FACTORS:
        raise ValueError(f"n_factors must be in 1..{MAX_FACTORS}")
    if not 0.005 <= bin_s <= 0.2:
        raise ValueError("bin_s must be in 0.005..0.2")
    event, groups, spikes, dropped = _aligned(src, event, group_by, t_before, t_after, units)
    if n_factors >= len(spikes):
        raise ValueError(f"n_factors must be below the number of units ({len(spikes)})")
    events = np.concatenate(list(groups.values()))
    labels = np.concatenate([[g] * len(v) for g, v in groups.items()])
    t, counts = aligned_counts(spikes, events, (-t_before, t_after), bin_s)
    counts = counts.transpose(0, 2, 1)  # (trials, bins, units)
    if counts.shape[0] * counts.shape[1] > 200_000:
        raise ValueError("too many trials x bins; shorten the window, raise bin_s or use fewer trials")
    fit = fit_pca(counts, n_factors) if method == "pca" else fit_gpfa(counts, n_factors, bin_s)
    _latents[session_id] = {"fit": fit, "t": t, "labels": labels, "event": event, "group_by": group_by}
    out = {"event": event, "window_s": [-t_before, t_after], "events_dropped_unrecorded": dropped}
    out.update(summarize_latent(fit, bin_s))
    beh = _behaviour_r2_from_latents(src, groups, t, fit.trajectories)
    if beh:
        out["behaviour_explained"] = beh
    mean = fit.trajectories.mean(axis=0)
    step = max(1, len(t) // 15)
    out["mean_trajectory_top3"] = [
        {"t": round(float(t[i]), 3), "factors": np.round(mean[i, :3], 3).tolist()} for i in range(0, len(t), step)
    ]
    return out


@tool(structured_output=False)
def plot_latent_factors(session_id: str, max_trials_drawn: int = 40) -> list:
    """Figure: the top three latent factors over time (single trials thin, group means bold), the
    trajectory in the plane of the first two factors, and variance explained per factor.
    Requires fit_latent_factors first."""
    if session_id not in _latents:
        raise ValueError("no latent model fitted; call fit_latent_factors first")
    L = _latents[session_id]
    fit = L["fit"]
    title = f"{fit.method.upper()} latents around {L['event']} · {fit.trajectories.shape[0]} trials"
    path = plots.plot_latents(
        f"{session_id}-latents", title, L["t"], fit.trajectories, L["labels"], fit.variance_explained, max_trials_drawn
    )
    return _figure(
        path, method=fit.method, n_factors=int(fit.trajectories.shape[2]), groups=sorted(set(L["labels"].tolist()))
    )


def _figure(path, **summary) -> list:
    return [{"saved_to": str(path), **summary}, Image(path=path)]


@tool(structured_output=False)
def plot_psth(
    session_id: str,
    event: str | None = None,
    group_by: str | None = None,
    t_before: float = 0.3,
    t_after: float = 0.6,
    bin_s: float = 0.02,
    units: list[int] | None = None,
) -> list:
    """Figure: population PSTH per group (mean ± SEM over trials) above a unit-by-time heatmap of
    change from baseline. Same arguments as get_psth. Returns the PNG path and the image."""
    src = _session(session_id)
    if not 0.005 <= bin_s <= 0.5:
        raise ValueError("bin_s must be in 0.005..0.5")
    event, groups, spikes, _ = _aligned(src, event, group_by, t_before, t_after, units)
    window = (-t_before, t_after)
    curves = {}
    for label, times in groups.items():
        t, counts = aligned_counts(spikes, times, window, bin_s)
        pop = counts.mean(axis=1) / bin_s  # population rate per trial
        sem = pop.std(axis=0, ddof=1) / np.sqrt(len(times)) if len(times) > 1 else np.zeros(pop.shape[1])
        curves[label] = (pop.mean(axis=0), sem, len(times))
    overall = compute_psth(spikes, np.concatenate(list(groups.values())), window, bin_s)
    pre = overall.t < 0
    base = overall.rate[:, pre].mean(axis=1, keepdims=True) if pre.any() else overall.rate.mean(axis=1, keepdims=True)
    sd = (overall.rate[:, pre].std(axis=1, keepdims=True) if pre.any() else 0.0) + 1.0
    n = sum(len(v) for v in groups.values())
    who = f"unit {units[0]}" if units and len(units) == 1 else f"{len(spikes)} units"
    title = f"Firing around {event} · {n} trials, {who}"
    rate_label = "Firing rate (Hz)" if len(spikes) == 1 else "Mean rate per unit (Hz)"
    path = plots.plot_psth(f"{session_id}-psth", title, event, t, curves, (overall.rate - base) / sd, rate_label)
    top = np.argsort(-np.abs(modulation(overall)))[:5]
    return _figure(path, event=event, n_events=n, groups=list(curves), most_modulated_units=[int(u) for u in top])


@tool(structured_output=False)
def plot_raster(session_id: str, t0: float = 0.0, duration_s: float = 10.0, max_units: int = 150) -> list:
    """Figure: spike raster for a time window (max 60 s), with unrecorded spans shaded."""
    src = _session(session_id)
    t0, t1 = _range(src, t0, t0 + min(max(duration_s, 0.1), 60.0))
    spikes = src.spike_times(t0, t1)[: max(1, min(max_units, 400))]
    title = f"Spike raster · {len(spikes)} units, {t0:g}–{t1:g} s"
    path = plots.plot_raster(f"{session_id}-raster", title, spikes, t0, t1, src.valid_intervals())
    return _figure(path, window_s=[t0, t1], n_units=len(spikes), total_spikes=int(sum(s.size for s in spikes)))


@tool(structured_output=False)
def plot_decoding(session_id: str, t0: float, duration_s: float = 10.0) -> list:
    """Figure: decoded against actual behaviour for a window (max 60 s), one panel per dimension.
    Requires fit_decoder first. Pick a window in the test split for an honest picture."""
    src = _session(session_id)
    if session_id not in _decoders:
        raise ValueError("no decoder fitted; call fit_decoder first")
    d = _decoders[session_id]
    t0, t1 = _range(src, t0, t0 + min(max(duration_s, 0.5), 60.0))
    lead = min(WARMUP_S, t0 - src.info().t_start_s)
    t, X, y = _xy(src, d["target"], t0 - lead, t1, d["bin_s"], d["mask"])
    keep = t >= t0
    t, y, yhat = t[keep], y[keep], d["model"].predict(X)[keep]
    r2 = r2_score(y, yhat)
    in_test = t0 >= d["test_start_s"]
    title = (
        f"{d['kind'].capitalize()} decoder · {d['target']} · {'held-out data' if in_test else 'includes training data'}"
    )
    unit = src.info().behavior_units.get(d["target"], "")
    path = plots.plot_decode(f"{session_id}-decode", title, t, y, yhat, unit, r2)
    return _figure(path, window_s=[t0, t1], r2_per_dim=[round(float(v), 3) for v in r2], held_out=bool(in_test))


@tool
def list_lsl_streams(wait_s: float = 3.0) -> dict:
    """Lab Streaming Layer streams visible on the local network (needs the lsl extra)."""
    streams = _lsl.list_streams(max(0.5, min(wait_s, 10.0)))
    return {
        "streams": streams,
        "hint": "open_session(source='lsl', params={'name': ...}) to subscribe" if streams else "none found",
    }


@tool
def get_stream_status(session_id: str) -> dict:
    """For a live session: how much signal is buffered, whether data is still arriving, and drops."""
    src = _session(session_id)
    live = src.inner if isinstance(src, SortedSource) else src
    if not isinstance(live, RingBufferSource):
        raise ValueError("not a live session; this tool applies to lsl sessions")  # noqa: TRY004 - a bad argument, not a type bug
    return live.status()


@tool
def search_datasets(query: str = "", limit: int = 10) -> dict:
    """Search the DANDI Archive for datasets. An empty query returns a short curated list of
    intracortical datasets that work well with this server."""
    if not query.strip():
        return {"curated": _dandi.CATALOG}
    return {"results": _dandi.search(query, limit), "curated": _dandi.CATALOG}


@tool
def list_dataset_files(dandiset_id: str, version: str = "", limit: int = 50) -> dict:
    """Licence, citation and NWB files of a DANDI dataset. Pass a file's path to open_session(source='dandi')."""
    meta = _dandi.describe(dandiset_id, version or None)
    return {**meta, "files": _dandi.list_files(dandiset_id, meta["version"], limit)}


@mcp.resource("ephys://sessions")
def sessions_resource() -> dict:
    """Currently open sessions."""
    return {sid: s.info().to_dict() for sid, s in _sessions.items()}


@mcp.prompt()
def analyze_session(session_id: str) -> str:
    """Walk through a standard first-pass analysis of a session."""
    return (
        f"Analyse session {session_id}: get_session_info, then get_signal_quality, then get_firing_rates. "
        "If a cursor or hand velocity signal exists, fit_decoder with kind='kalman' and with kind='ridge', "
        "compare held-out R², and plot_decoding on a test segment. If the session has trial events, "
        "get_psth and plot_psth grouped by a sensible column, then fit_latent_factors (gpfa) and "
        "plot_latent_factors to see population dynamics. Summarise findings and caveats."
    )


@mcp.prompt()
def falcon_evaluate(dandiset_id: str = "000954") -> str:
    """Run a FALCON-style cross-session evaluation on a FALCON dataset from DANDI."""
    return (
        f"Evaluate decoder stability across days on DANDI {dandiset_id} (a FALCON benchmark dataset). "
        "Call list_dataset_files and note the three groups: held-in-calib (training days), held-in-minival "
        "(small same-day validation) and held-out-calib (later days). Open one held-in-calib file, its "
        "matching held-in-minival file (same session date in the name), and two or three held-out-calib "
        "files with open_session(source='dandi'). Then evaluate_cross_session with the calib file as "
        "train_session_id, the others as test_session_ids, kind='ridge', bin_s=0.02 and mask='eval_mask'. "
        "Report the minival R² as the same-day reference and each later day's R² against it, per dimension "
        "where informative. State plainly that FALCON's official test labels are private, so these numbers "
        "are not leaderboard scores, and cite the dataset from get_session_info."
    )


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
